<?php

declare(strict_types=1);

namespace IctDataCleanerPro\Service;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\Uuid\Uuid;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpKernel\KernelInterface;

class CleanupLoggerService
{
    private EntityRepository $cleanupLogRepository;
    private LoggerInterface $logger;
    private string $logBaseDir;

    public function __construct(
        EntityRepository $cleanupLogRepository,
        LoggerInterface $logger,
        KernelInterface $kernel
    ) {
        $this->cleanupLogRepository = $cleanupLogRepository;
        $this->logger = $logger;

        // Use Symfony kernel to resolve log dir path
        $this->logBaseDir = $kernel->getLogDir() . '/ict-data-cleaner';

        // Ensure the log directory exists
        if (!is_dir($this->logBaseDir)) {
            mkdir($this->logBaseDir, 0775, true);
        }
    }

    public function logCleanupRun(
        string $trigger,
        string $mode,
        array $config,
        array $results,
        Context $context
    ): void {
        $data = [
            'id' => Uuid::randomHex(),
            'runAt' => new \DateTime(),
            'trigger' => $trigger,
            'mode' => $mode,
            'configSnapshot' => $config,
            'results' => $this->formatResults($results)
        ];

        try {
            $this->cleanupLogRepository->create([$data], $context);

            $this->logger->info('Data cleanup completed', [
                'trigger' => $trigger,
                'mode' => $mode,
                'totalItems' => $this->countTotalItems($results)
            ]);
        } catch (\Exception $e) {
            $this->logger->error('Failed to log cleanup run', [
                'error' => $e->getMessage()
            ]);
        }
    }

    private function formatResults(array $results): array
    {
        $formatted = [];

        foreach ($results as $handlerClass => $handlerResults) {
            $formatted[] = [
                'handler' => $handlerResults['name'] ?? $handlerClass,
                'items' => $handlerResults['items'] ?? []
            ];
        }

        return $formatted;
    }

    private function countTotalItems(array $results): int
    {
        $total = 0;

        foreach ($results as $handlerResults) {
            if (isset($handlerResults['items'])) {
                foreach ($handlerResults['items'] as $itemResults) {
                    $total += $itemResults['count'] ?? 0;
                }
            }
        }

        return $total;
    }

    public function logToFile(string $module, string $level, array $data): void
    {
        $timestamp = (new \DateTime())->format('Y-m-d H:i:s');
        $filePath = sprintf('%s/%s.log', $this->logBaseDir, strtolower($module));

        $entry = sprintf("[%s] [%s] %s\n", $timestamp, strtoupper($level), json_encode($data, JSON_UNESCAPED_UNICODE));

        file_put_contents($filePath, $entry, FILE_APPEND);
    }

    public function logSuccess(string $module, array $data): void
    {
        $this->logToFile($module, 'info', ['status' => 'success'] + $data);
    }

    public function logError(string $module, \Throwable $e, array $context = []): void
    {
        $this->logToFile($module, 'error', [
            'message' => $e->getMessage(),
            'context' => $context,
            'trace' => $e->getTraceAsString(),
        ]);
    }
}
