import template from './blog-detail.html.twig';


const { Component,Criteria, EntityCollection } = Shopware.Data;

Shopware.Component.register('blog-detail', {
    template,

    inject: ['repositoryFactory'],
    

    

    data() {
        return {
           isLoading: false,
           categoryCriteria: new Criteria(1, 25),
            blog: {
            name: '',
            description: '',
            releaseDate: null,
            active: false,
               categories: new EntityCollection(
               'blog_category', // entity
               'id',             // entity primary key
                Shopware.Context.api, // context
                new Criteria()    // optional criteria
            ),
            author: '',
            products: new EntityCollection('product', 'id', Shopware.Context.api, new Criteria()),
         }
        }   
    },
//     created() {
//     const repository = this.repositoryFactory.create('blog');

//     this.blog = repository.create(Shopware.Context.api); // creates a new entity
// },

    created() {
    const id = this.$route.params.id;
    const repository = this.repositoryFactory.create('blog');

    if (id) {
        repository.get(id, Shopware.Context.api).then((blog) => {
            this.blog = blog;
        }).catch(() => {
            console.log('error loading blog');
        });
    } else {
        this.blog = repository.create(Shopware.Context.api);
        this.blog.categories = [];
        this.blog.products = [];
    }
},


    computed: {
        categoryCriteria() {
            const criteria = new Criteria(1, 25);
            criteria.addFilter(
                Criteria.equals('active', true)
            );
            criteria.addSorting(Criteria.sort('name', 'ASC'));
            return criteria;
        },
          productCriteria() {
        const criteria = new Criteria(1, 25);
        criteria.addFilter(Criteria.equals('active', true)); // optional: only active products
        criteria.addSorting(Criteria.sort('name', 'ASC'));
        return criteria;
    }
    },

    methods: {
    onSave() {
    this.isLoading = true;


    const repository = this.repositoryFactory.create('blog');
    console.log(repository);
    
    repository.save(this.blog, Shopware.Context.api).then(() => {
        this.isLoading = false;
        this.$router.push({ name: 'sw.blog.index' });
    }).catch((e) => {
        this.isLoading = false;
        console.error('Save failed:', e);
    });
}
,
  
    onCancel() {
        this.$router.back();
    },
    onCategoryChange(categories) {        
    this.blog.categories = categories;
    },
    onProductChange(products) {
    this.blog.products = products;
    },

    }

  });
