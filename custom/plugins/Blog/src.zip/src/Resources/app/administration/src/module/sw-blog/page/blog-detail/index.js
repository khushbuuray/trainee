import template from './blog-detail.html.twig';

const { Criteria, EntityCollection } = Shopware.Data;

Shopware.Component.register('blog-detail', {
    template,

    inject: ['repositoryFactory'],

    

    data() {
        return {
           isLoading: false,
           categoryCriteria: new Criteria(1, 25),
            blog: {
            name: '',
            description: '',
            releaseDate: null,
            active: false,
            categories: new EntityCollection(
                    '/blog-category',
                    'blog_category',
                    Shopware.Context.api,
                    new Criteria(),
                    []
                ),

            author: '',
            product: ''
         }
        }   
    },
    methods: {
    onSave() {
        this.isLoading = true;

        const repository = this.repositoryFactory.create('blog');
        repository.save(this.blog, Shopware.Context.api).then(() => {
            this.isLoading = false;
                this.$router.push({ name: 'sw.blog.index' });

            // this.createNotificationSuccess({ title: 'Saved', message: 'Blog category saved.' });
        }).catch(() => {
            this.isLoading = false;
            // this.createNotificationError({ title: 'Error', message: 'Save failed.' });
        });
    },
    onCancel() {
        this.$router.back();
    }
    }

});