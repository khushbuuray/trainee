<?php declare(strict_types=1);

namespace Blog\Storefront\Controller;

use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpCache\Store;
use Symfony\Component\Routing\Annotation\Route; 


class HelloworldController extends StorefrontController
{ 
    #[Route(path:'/hello-world', name:'frontend.helloworld', methods: ['GET'])]

    public function index(): Response
    {
        dd('hi');
        return $this->renderStorefront('@Blog/storefront/page/helloworld.html.twig',[
            'exaple'=>'Hello world'
        ]);
    }
}